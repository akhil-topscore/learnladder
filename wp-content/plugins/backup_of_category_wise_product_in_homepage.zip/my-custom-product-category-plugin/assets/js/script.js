jQuery(document).ready(function ($) {
    var firstCategoryId = mcpc_ajax_object.first_category_id;
  
    if (firstCategoryId) {
      setActiveButton(firstCategoryId);
      showCategoryProducts(firstCategoryId);
    }
  
    $(".mcpc-category-button").on("click", function () {
      var categoryId = $(this).data("category");
  
      if ($(this).hasClass("active-button")) {
        return; 
      }
  
      setActiveButton(categoryId);
      showCategoryProducts(categoryId);
    });
  
    function showCategoryProducts(categoryId) {
      $(".loader").show(); 
  
      $(".product-cards").hide();
  
      setTimeout(function () {
        $(".loader").hide(); 
        $('.product-cards[data-category="' + categoryId + '"]').show(); 
      }, 300); 
    }
  
    function setActiveButton(categoryId) {
      $(".mcpc-category-button").removeClass("active-button");
      var activeButton = $('.mcpc-category-button[data-category="' + categoryId + '"]');
      activeButton.addClass("active-button");
    }
  });
  