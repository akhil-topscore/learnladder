<?php
function mcpc_display_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
    ));

    $first_category_id = !empty($categories) ? $categories[0]->term_id : 0;

    ob_start(); ?>

    <div class="mcpc-categories">
        <?php foreach ($categories as $category) : ?>
            <button class="mcpc-category-button" data-category="<?php echo esc_attr($category->term_id); ?>">
                <?php echo esc_html($category->name); ?>
            </button>
        <?php endforeach; ?>
    </div>

    <div class="loader" style="display:none;"></div>

    <div id="mcpc-product-loop" class="mcpc-product-loop">
        <?php foreach ($categories as $category) : 
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_cat',
                        'field' => 'term_id',
                        'terms' => $category->term_id,
                    ),
                ),
            );
            $loop = new WP_Query($args);
            if ($loop->have_posts()) : ?>
                <div class="product-cards" data-category="<?php echo esc_attr($category->term_id); ?>" style="display:none;">
                    <?php while ($loop->have_posts()) : $loop->the_post();
                        $product = wc_get_product(get_the_ID());
                        if (!$product) {
                            continue;
                        }
                        ?>
                        <div class="product-card">
                            <div class="product-image">
                                <?php echo wp_kses_post($product->get_image()); ?>
                            </div>
                            <h2 class="product-title"><?php echo esc_html($product->get_name()); ?></h2>
                            <p class="product-description"><?php echo esc_html(wp_trim_words($product->get_description(), 20)); ?></p>
                            <div class="product-price">
                                <?php if ($product->is_on_sale()) : ?>
                                    <span class="reduced-price"><?php echo wp_kses_post(wc_price($product->get_regular_price())); ?></span>
                                    <span class="current-price"><?php echo wp_kses_post(wc_price($product->get_sale_price())); ?></span>
                                <?php else : ?>
                                    <span class="current-price"><?php echo wp_kses_post($product->get_price_html()); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif;
            wp_reset_postdata();
        endforeach; ?>
    </div>

    <?php
    wp_enqueue_style('mcpc-style', plugin_dir_url(__FILE__) . 'style.css');
    wp_enqueue_script('mcpc-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), null, true);
    wp_localize_script('mcpc-script', 'mcpc_ajax_object', array(
        'first_category_id' => $first_category_id,
    ));

    return ob_get_clean();
}
add_shortcode('mcpc_categories', 'mcpc_display_categories');

function mcpc_fetch_products() {
    $category_id = intval($_POST['category_id']);
    
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 4,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id,
            ),
        ),
    );

    $loop = new WP_Query($args);
    
    ob_start();
    if ($loop->have_posts()) :
        echo '<div class="product-cards">';
        while ($loop->have_posts()) : $loop->the_post();
            $product = wc_get_product(get_the_ID());
            if (!$product) {
                continue;
            }
            ?>
            <div class="product-card">
                <div class="product-image">
                    <?php echo wp_kses_post($product->get_image()); ?>
                </div>
                <h2 class="product-title"><?php echo esc_html($product->get_name()); ?></h2>
                <p class="product-description"><?php echo esc_html(wp_trim_words($product->get_description(), 20)); ?></p>
                <div class="product-price">
                    <?php if ($product->is_on_sale()) : ?>
                        <span class="reduced-price"><?php echo wp_kses_post(wc_price($product->get_regular_price())); ?></span>
                        <span class="current-price"><?php echo wp_kses_post(wc_price($product->get_sale_price())); ?></span>
                    <?php else : ?>
                        <span class="current-price"><?php echo wp_kses_post($product->get_price_html()); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        endwhile;
        echo '</div>';
    else :
        echo '<p>No products found in this category.</p>';
    endif;

    wp_reset_postdata();
    
    echo ob_get_clean();
    wp_die();
}

add_action('wp_ajax_mcpc_fetch_products', 'mcpc_fetch_products');
add_action('wp_ajax_nopriv_mcpc_fetch_products', 'mcpc_fetch_products');
