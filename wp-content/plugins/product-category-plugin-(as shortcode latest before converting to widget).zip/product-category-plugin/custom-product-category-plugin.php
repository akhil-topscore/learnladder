<?php
/**
 * Plugin Name: Product_category
 * Description: A plugin to display WooCommerce products by category in Elementor.
 * Version: 1.0
 * Author: AKHIL JOHNS
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; 
}

// Enqueue the necessary CSS and JS files
function mcpc_enqueue_assets() {
    wp_enqueue_style('mcpc-style', plugins_url('assets/css/style.css', __FILE__)); // Load the style.css file
    wp_enqueue_script('mcpc-script', plugins_url('assets/js/script.js', __FILE__), array('jquery'), null, true); // Load the script.js file
}
add_action('wp_enqueue_scripts', 'mcpc_enqueue_assets');

require_once plugin_dir_path( __FILE__ ) . 'includes/product-category-loop.php';

function mcpc_enqueue_scripts() {
    wp_enqueue_script('mcpc-script', plugin_dir_url(__FILE__) . 'assets/js/script.js', array('jquery'), null, true);
    wp_localize_script('mcpc-script', 'mcpc_ajax_obj', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
    wp_enqueue_style('mcpc-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
}
add_action('wp_enqueue_scripts', 'mcpc_enqueue_scripts');
