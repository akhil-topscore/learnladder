<?php

function mcpc_display_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'parent' => 0,
        'hide_empty' => false,
    ));

    $valid_categories = array();
    foreach ($categories as $category) {
        $product_count = count(get_posts(array(
            'post_type' => 'product',
            'posts_per_page' => 1,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category->term_id,
                ),
            ),
        )));
        if ($product_count > 0) {
            $valid_categories[] = $category;
        }
    }

    ob_start(); ?>

<div class="mcpc-filter-container">
    <div class="mcpc-filter-control">
        <span class="mcpc-filter-text">Filter Options</span>
        <div class="mcpc-horizontal-divider"></div>
        <button id="mcpc-filter-button" class="mcpc-filter-button">Filter</button>
    </div>
    <div class="loader" style="display: none;"></div>
    <div id="mcpc-filter-section" class="mcpc-filter-section" style="display: none;">
        <div class="mcpc-filter-header">
            <h3>Filter Products</h3>
            <button class="mcpc-close-button" aria-label="Close filter">X</button>
        </div>
        <div class="mcpc-filter-content">
            <div class="mcpc-filter-grid">
                <div class="mcpc-filter-col">
                    <label for="parent-category">Parent Category:</label>
                    <select id="parent-category" class="mcpc-select">
                        <option value="">Select Parent Category</option>
                        <?php foreach ($valid_categories as $category) : ?>
                            <option value="<?php echo esc_attr($category->term_id); ?>"><?php echo esc_html($category->name); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mcpc-filter-col">
                    <label for="child-category">Subcategory:</label>
                    <select id="child-category" class="mcpc-select" disabled>
                        <option value="">No child category available</option>
                    </select>
                </div>

                <div class="mcpc-filter-col mcpc-search-container">
                    <label for="search-bar">Search:</label>
                    <input type="text" id="search-bar" class="mcpc-search-bar" placeholder="Search products...">
                    <button id="search-button" class="mcpc-search-button">Search</button>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="mcpc-product-loop" class="custom-product-cards-grid"></div>

<?php
    wp_enqueue_style('mcpc-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    return ob_get_clean();
}

add_shortcode('mcpc_categories', 'mcpc_display_categories');

function mcpc_get_child_categories() {
    $parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;
    $child_categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'parent' => $parent_id,
        'hide_empty' => false,
    ));

    ob_start();
    if (!empty($child_categories)) {
        foreach ($child_categories as $child) {
            echo '<option value="' . esc_attr($child->term_id) . '">' . esc_html($child->name) . '</option>';
        }
    } else {
        echo '<option value="">No child category available</option>';
    }
    wp_send_json_success(ob_get_clean());
}
add_action('wp_ajax_mcpc_get_child_categories', 'mcpc_get_child_categories');
add_action('wp_ajax_nopriv_mcpc_get_child_categories', 'mcpc_get_child_categories');

function mcpc_filter_products() {
    $parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;
    $child_id = isset($_GET['child_id']) ? intval($_GET['child_id']) : 0;
    $search_term = isset($_GET['search_term']) ? sanitize_text_field($_GET['search_term']) : '';

    $tax_query = array();
    if ($parent_id) {
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field' => 'term_id',
            'terms' => $parent_id,
        );
    }
    if ($child_id) {
        $tax_query[] = array(
            'taxonomy' => 'product_cat',
            'field' => 'term_id',
            'terms' => $child_id,
        );
    }

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 8, // Limit to 8 products
        'tax_query' => $tax_query,
        's' => $search_term,
    );
    $loop = new WP_Query($args);

    ob_start();
    if ($loop->have_posts()) :
        while ($loop->have_posts()) : $loop->the_post();
            $product = wc_get_product(get_the_ID());

            // Ensure title and description are properly retrieved
            $title = $product->get_name();
            $description = $product->get_description();

            ?>
            <div class="custom-product-card-item">
                <a href="<?php echo esc_url(get_permalink()); ?>" class="custom-product-link">
                    <div class="custom-product-image"><?php echo wp_kses_post($product->get_image()); ?></div>
                    <h2 class="custom-product-title"><?php echo esc_html($title); ?></h2>
                    <p class="custom-product-description"><?php echo esc_html(wp_trim_words($description, 20)); ?></p>
                    <div class="custom-product-price">
                        <?php
                        if ($product->is_on_sale()) {
                            echo '<span class="custom-reduced-price">' . wc_price($product->get_regular_price()) . '</span>';
                            echo '<span class="custom-current-price">' . wc_price($product->get_sale_price()) . '</span>';
                        } else {
                            echo '<span class="custom-current-price">' . wc_price($product->get_price()) . '</span>';
                        }
                        ?>
                    </div>
                </a>
            </div>
            <?php
        endwhile;
    else :
        echo '<div class="no-products-overlay" style="text-align: center;">
            <div class="no-products-message">
                <strong>No products found.</strong><br>Try adjusting your filters or search term.
            </div>
          </div>';
    endif;
    wp_reset_postdata();

    echo ob_get_clean();
    wp_die();
}

add_action('wp_ajax_mcpc_filter_products', 'mcpc_filter_products');
add_action('wp_ajax_nopriv_mcpc_filter_products', 'mcpc_filter_products');
?>


