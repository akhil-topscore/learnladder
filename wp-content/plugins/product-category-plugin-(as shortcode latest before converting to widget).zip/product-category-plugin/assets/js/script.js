jQuery(document).ready(function($) {
    const filterButton = $('#mcpc-filter-button');
    const filterSection = $('#mcpc-filter-section');
    const productLoop = $('#mcpc-product-loop');
    const loader = $('.loader');
    const parentCategorySelect = $('#parent-category');
    const childCategorySelect = $('#child-category');
    const searchBar = $('#search-bar');
    const searchButton = $('#search-button');

    function setLoadingState(isLoading) {
        if (isLoading) {
            loader.show();
            parentCategorySelect.prop('disabled', true);
            childCategorySelect.prop('disabled', true);
            searchBar.prop('disabled', true);
        } else {
            loader.hide();
            parentCategorySelect.prop('disabled', false);
            childCategorySelect.prop('disabled', false);
            searchBar.prop('disabled', false);
        }
    }

    // Fetch initial default products on page load
    fetchInitialProducts();

    function fetchInitialProducts() {
        const defaultParentId = parentCategorySelect.val(); // Get the default parent category ID
        setLoadingState(true);
        fetchProducts(defaultParentId, '', '');
    }

    // Toggle the filter section on button click
    filterButton.on('click', function() {
        filterSection.slideToggle();
        filterSection.toggleClass('open');
        productLoop.toggleClass('shifted');
    });

    parentCategorySelect.on('change', function() {
        const selectedParent = $(this).val();
        setLoadingState(true);
        fetchSubcategories(selectedParent);
        fetchProducts(selectedParent, childCategorySelect.val(), searchBar.val());
    });

    childCategorySelect.on('change', function() {
        setLoadingState(true);
        fetchProducts(parentCategorySelect.val(), $(this).val(), searchBar.val());
    });

    // Trigger search only on button click or Enter key press
    searchButton.on('click', function() {
        setLoadingState(true);
        fetchProducts(parentCategorySelect.val(), childCategorySelect.val(), searchBar.val());
    });

    function fetchProducts(parentId, childId, searchTerm) {
        $.ajax({
            url: mcpc_ajax_obj.ajax_url,
            method: 'GET',
            data: {
                action: 'mcpc_filter_products',
                parent_id: parentId,
                child_id: childId,
                search_term: searchTerm
            },
            success: function(data) {
                productLoop.html(data);
                setLoadingState(false);
            }
        });
    }

    function fetchSubcategories(parentId) {
        $.ajax({
            url: mcpc_ajax_obj.ajax_url,
            method: 'GET',
            data: {
                action: 'mcpc_get_child_categories',
                parent_id: parentId
            },
            success: function(data) {
                if (data.success && data.data.trim() !== '') {
                    childCategorySelect.html(data.data);
                    childCategorySelect.prop('disabled', false);
                } else {
                    childCategorySelect.html('<option value="">No child category available</option>');
                    childCategorySelect.prop('disabled', true);
                }
            }
        });
    }
});
