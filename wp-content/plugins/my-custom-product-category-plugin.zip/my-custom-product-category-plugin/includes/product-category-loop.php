<?php
function mcpc_display_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'parent' => 0,
        'hide_empty' => false,
    ));

    ob_start(); ?>

    <div class="mcpc-filter-container">
        <button id="mcpc-filter-button" class="mcpc-filter-button">Filter</button>
        <div id="mcpc-filter-section" class="mcpc-filter-section" style="display: none;">
            <div class="mcpc-filter-content">
                <h3>Filter Products</h3>
                
                <label for="parent-category">Parent Category:</label>
                <select id="parent-category" class="mcpc-select">
                    <option value="">Select Parent Category</option>
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?php echo esc_attr($category->term_id); ?>"><?php echo esc_html($category->name); ?></option>
                    <?php endforeach; ?>
                </select>

                <div id="subcategory-container">
                    <label for="child-category">Subcategory:</label>
                    <select id="child-category" class="mcpc-select">
                        <option value="">No child category available</option>
                    </select>
                </div>

                <label for="search-bar">Search:</label>
                <input type="text" id="search-bar" class="mcpc-search-bar" placeholder="Search products...">
            </div>
        </div>
    </div>

    <div id="mcpc-product-loop" class="mcpc-product-loop">
        <?php 
        $no_products = true; // Flag to track if products are available
        foreach ($categories as $parent) :
            $args = array(
                'post_type' => 'product',
                'posts_per_page' => -1,
                'tax_query' => array(
                    array(
                        'taxonomy' => 'product_cat',
                        'field' => 'term_id',
                        'terms' => $parent->term_id,
                    ),
                ),
            );
            $loop = new WP_Query($args);
            if ($loop->have_posts()) : 
                $no_products = false; ?>
                <div class="product-cards" data-category="<?php echo esc_attr($parent->term_id); ?>" style="display: none;">
                    <?php while ($loop->have_posts()) : $loop->the_post();
                        $product = wc_get_product(get_the_ID());
                        ?>
                        <div class="custom-product-card">
                            <div class="product-image">
                                <?php echo wp_kses_post($product->get_image()); ?>
                            </div>
                            <h2 class="product-title"><?php echo esc_html($product->get_name()); ?></h2>
                            <p class="product-description"><?php echo esc_html(wp_trim_words($product->get_description(), 20)); ?></p>
                            <div class="product-price">
                                <?php if ($product->is_on_sale()) : ?>
                                    <span class="reduced-price"><?php echo wp_kses_post(wc_price($product->get_regular_price())); ?></span>
                                    <span class="current-price"><?php echo wp_kses_post(wc_price($product->get_sale_price())); ?></span>
                                <?php else : ?>
                                    <span class="current-price"><?php echo wp_kses_post($product->get_price_html()); ?></span>
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo esc_url(get_permalink()); ?>" class="view-product-button">View Product</a>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif;
            wp_reset_postdata();
        endforeach;

        if ($no_products) {
            echo '<div class="no-products-message">No products available.</div>';
        }
        ?>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const parentCategorySelect = document.getElementById('parent-category');
            const childCategorySelect = document.getElementById('child-category');
            const searchBar = document.getElementById('search-bar');
            const productCardsContainers = document.querySelectorAll('.product-cards');

            parentCategorySelect.addEventListener('change', function () {
                const selectedCategory = this.value;
                
                // Reset child category selection
                childCategorySelect.innerHTML = '<option value="">No child category available</option>';
                childCategorySelect.disabled = true;

                if (selectedCategory) {
                    fetchSubcategories(selectedCategory);
                }

                productCardsContainers.forEach(function (container) {
                    container.style.display = container.getAttribute('data-category') === selectedCategory || selectedCategory === '' ? 'block' : 'none';
                });
            });

            function fetchSubcategories(parentId) {
                fetch(`<?php echo admin_url('admin-ajax.php'); ?>?action=mcpc_get_child_categories&parent_id=${parentId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success && data.data.trim() !== '') {
                            childCategorySelect.innerHTML = data.data;
                            childCategorySelect.disabled = false;
                        }
                    });
            }

            searchBar.addEventListener('input', function () {
                const searchTerm = this.value.toLowerCase();
                productCardsContainers.forEach(function (container) {
                    container.querySelectorAll('.custom-product-card').forEach(function (card) {
                        const title = card.querySelector('.product-title').innerText.toLowerCase();
                        card.style.display = title.includes(searchTerm) ? 'block' : 'none';
                    });
                });
            });
        });
    </script>

    <?php
    wp_enqueue_style('mcpc-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    return ob_get_clean();
}
add_shortcode('mcpc_categories', 'mcpc_display_categories');



// Ajax to fetch child categories dynamically
function mcpc_get_child_categories() {
    $parent_id = isset($_GET['parent_id']) ? intval($_GET['parent_id']) : 0;
    $child_categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'parent' => $parent_id,
        'hide_empty' => false,
    ));

    ob_start();
    foreach ($child_categories as $child) {
        echo '<option value="' . esc_attr($child->term_id) . '">' . esc_html($child->name) . '</option>';
    }
    wp_send_json_success(ob_get_clean());
}
add_action('wp_ajax_mcpc_get_child_categories', 'mcpc_get_child_categories');
add_action('wp_ajax_nopriv_mcpc_get_child_categories', 'mcpc_get_child_categories');
