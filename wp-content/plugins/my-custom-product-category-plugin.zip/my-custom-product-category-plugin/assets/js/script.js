jQuery(document).ready(function($) {
    $('#mcpc-filter-button').on('click', function() {
        $('#mcpc-filter-section').slideToggle(); // Slide toggle for showing/hiding the filter section
        $('#mcpc-product-loop').toggleClass('shifted'); // Add/remove class for pushing down/up the product loop
    });

    productCardsContainers.forEach(function (container) {
        if (container.getAttribute('data-category') === selectedCategory || selectedCategory === '') {
            container.classList.add('visible');
        } else {
            container.classList.remove('visible');
        }
    });
    

});

