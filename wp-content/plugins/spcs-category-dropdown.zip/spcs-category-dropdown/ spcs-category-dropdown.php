<?php
/*
Plugin Name: SPCs Category Dropdown
Description: A custom plugin to display WooCommerce product categories in a dropdown menu with sorting and filtering functionality.
Version: 1.2
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

// Register the shortcode
function spcs_category_dropdown_shortcode() {
    if (!class_exists('WooCommerce')) {
        return '<p>WooCommerce is required for this functionality.</p>';
    }

    $categories = get_terms([
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'parent' => 0,
    ]);

    ob_start(); ?>
    <div class="spcs-category-container">
        <div class="spcs-category-dropdown">
            <h3 class="spcs-category-heading">
                Category Filter
                <i class="fa fa-chevron-down"></i> <!-- Add the icon here -->
            </h3>
            <ul class="spcs-category-list">
                <?php foreach ($categories as $category): ?>
                    <li class="spcs-category-item <?php echo spcs_has_children($category->term_id) ? 'has-children' : ''; ?>">
                        <a href="<?php echo get_term_link($category->term_id); ?>" class="spcs-category-link">
                            <?php if (spcs_has_children($category->term_id)): ?>
                                <span class="spcs-child-indicator"><i class="fa fa-chevron-down"></i></span>
                            <?php endif; ?>
                            <?php echo esc_html($category->name); ?>
                        </a>
                        <?php if (spcs_has_children($category->term_id)): ?>
                            <ul class="spcs-subcategory-list">
                                <?php
                                $subcategories = get_terms([
                                    'taxonomy' => 'product_cat',
                                    'hide_empty' => false,
                                    'parent' => $category->term_id,
                                ]);
                                foreach ($subcategories as $subcategory): ?>
                                    <li>
                                        <a href="<?php echo get_term_link($subcategory->term_id); ?>">
                                            <?php echo esc_html($subcategory->name); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="spcs-sorting-dropdown">
            <h3 class="spcs-sorting-heading">Sort By</h3>
            <select id="spcs-sorting-select" class="spcs-sorting-select">
                <option value="menu_order">Default Sorting</option>
                <option value="popularity">Sort by Popularity</option>
                <option value="rating">Sort by Rating</option>
                <option value="date">Sort by Latest</option>
                <option value="price">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
            </select>
        </div>
    </div>
    <?php return ob_get_clean();
}
add_shortcode('spcs_category_dropdown', 'spcs_category_dropdown_shortcode');

// Helper function to check for children
function spcs_has_children($cat_id) {
    $children = get_terms([
        'taxonomy' => 'product_cat',
        'hide_empty' => false,
        'parent' => $cat_id,
    ]);
    return !empty($children);
}

// Enqueue styles and scripts
function spcs_enqueue_scripts() {
    wp_enqueue_style('spcs-style', plugins_url('/css/spcs-style.css', __FILE__));
    wp_enqueue_script('spcs-script', plugins_url('/js/spcs-script.js', __FILE__), ['jquery'], null, true);
}
add_action('wp_enqueue_scripts', 'spcs_enqueue_scripts');
?>
