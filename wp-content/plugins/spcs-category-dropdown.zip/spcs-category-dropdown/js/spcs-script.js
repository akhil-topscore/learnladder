document.addEventListener('DOMContentLoaded', function () {
    const categoryHeading = document.querySelector('.spcs-category-heading');
    const categoryDropdown = document.querySelector('.spcs-category-list');

    // Toggle category filter visibility on both mobile and desktop
    if (categoryHeading && categoryDropdown) {
        categoryHeading.addEventListener('click', function () {
            console.log("Category heading clicked"); // Log click event
            categoryDropdown.classList.toggle('show'); // Toggle visibility on click
            console.log("Dropdown visibility toggled: ", categoryDropdown.classList.contains('show')); // Check visibility state
        });
    }

    // Sorting logic
    const sortingSelect = document.querySelector('#spcs-sorting-select');

    // Handle sorting option change
    if (sortingSelect) {
        sortingSelect.addEventListener('change', function () {
            const selectedValue = this.value;
            const currentUrl = new URL(window.location.href);
            currentUrl.searchParams.set('orderby', selectedValue);
            window.location.href = currentUrl.href;
        });
    }

    // Handle subcategory toggle
    const categoryItems = document.querySelectorAll('.spcs-category-item.has-children');
    categoryItems.forEach(item => {
        const childIndicator = item.querySelector('.spcs-child-indicator');
        const subcategoryList = item.querySelector('.spcs-subcategory-list');

        if (childIndicator && subcategoryList) {
            childIndicator.addEventListener('click', function (e) {
                e.preventDefault();
                subcategoryList.classList.toggle('show');
                item.classList.toggle('expanded');
            });
        }
    });
});