<?php
/**
 * Plugin Name: Product-Card
 * Description: A custom Elementor widget for displaying product cards.
 * Version: 1.0
 * Author: Akhil Johns
 * Author URI: akhiljohns.site
 * Text Domain: custom-product-card
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function custom_product_card_enqueue_styles() {
    wp_enqueue_style( 'custom-product-card-styles', plugins_url( '/assets/css/styles.css', __FILE__ ) );
}

add_action( 'wp_enqueue_scripts', 'custom_product_card_enqueue_styles' );

function register_custom_product_card_widget( $widgets_manager ) {
    require_once( __DIR__ . '/includes/class-custom-product-card.php' );
    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Custom_Product_Card() );
}
add_action( 'elementor/widgets/widgets_registered', 'register_custom_product_card_widget' );

function custom_product_card_enqueue_scripts() {
    // Enqueue jQuery (WordPress includes it by default)
    wp_enqueue_script('jquery');

    // Enqueue your custom JavaScript file
    wp_enqueue_script(
        'custom-product-card-js', // Handle name
        plugins_url('assets/js/custom-product-card.js', __FILE__), // Path to your JS file
        array('jquery'), // Dependencies
        null, // Version (use null for no version)
        true // Load in footer
    );
}

// Hook the function to wp_enqueue_scripts
add_action('wp_enqueue_scripts', 'custom_product_card_enqueue_scripts');