jQuery(document).ready(function($) {
    console.log("jhoi")
    function adjustCardHeights() {
        var maxHeight = 0;

        // Reset heights to allow recalculating
        $('.custom-product-card-item, .custom-extra-image').css('height', 'auto');

        // Calculate the maximum height
        $('.custom-product-card-item, .custom-extra-image').each(function() {
            var thisHeight = $(this).outerHeight();
            if (thisHeight > maxHeight) {
                maxHeight = thisHeight;
            }
        });

        // Set all to the maximum height
        $('.custom-product-card-item, .custom-extra-image').css('height', maxHeight + 'px');
    }

    // Call on load and resize
    adjustCardHeights();
    $(window).resize(function() {
        adjustCardHeights();
    });
});
