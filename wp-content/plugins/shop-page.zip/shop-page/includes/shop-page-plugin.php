<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}



class Shop_Page_Widget extends Widget_Base {

    public function get_name() {
        return 'shop_page_widget';
    }

    public function get_title() {
        return 'Shop Page Widget';
    }

    public function get_icon() {
        return 'eicon-products';
    }

    public function get_categories() {
        return [ 'general' ];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => 'Content',
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        // Add controls for sorting, filtering, etc.
        $this->add_control(
            'parent_category',
            [
                'label' => 'Parent Category',
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '0',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        ?>
        <div id="sp-shop-page-widget">
            <select id="sp-parent-category">
                <option value="0">Select Parent Category</option>
                <!-- Dynamically populate this with categories via AJAX if needed -->
            </select>
            <select id="sp-child-category">
                <option value="0">Select Child Category</option>
            </select>
            <button id="sp-sort-by-price">Sort by Price</button>
            <div id="sp-products-list">
                <!-- Products will be loaded here via AJAX -->
            </div>
        </div>
        <?php
    }

    protected function _content_template() {}
}

// Register the widget
function sp_register_shop_page_widget( $widgets_manager ) {
    $widgets_manager->register( new \Shop_Page_Widget() );
}
add_action( 'elementor/widgets/register', 'sp_register_shop_page_widget' );

// AJAX Handlers

// Get Child Categories AJAX Handler
function sp_get_child_categories() {
    $parent_category = $_GET['parent_category'] ?? 0;

    if (!$parent_category) {
        wp_send_json_error( [ 'message' => 'Invalid Parent Category' ] );
    }

    $child_categories = get_terms( [
        'taxonomy' => 'product_cat',
        'parent' => $parent_category,
        'hide_empty' => false
    ] );

    ob_start();
    echo '<option value="0">Select Child Category</option>';
    foreach ( $child_categories as $child_category ) {
        echo '<option value="' . esc_attr( $child_category->term_id ) . '">' . esc_html( $child_category->name ) . '</option>';
    }
    $output = ob_get_clean();

    wp_send_json_success( $output );
}
add_action( 'wp_ajax_sp_get_child_categories', 'sp_get_child_categories' );
add_action( 'wp_ajax_nopriv_sp_get_child_categories', 'sp_get_child_categories' );

// Get Products AJAX Handler
function sp_get_products() {
    $parent_category = $_GET['parent_category'] ?? 0;
    $child_category = $_GET['child_category'] ?? 0;
    $sort_by = $_GET['sort_by'] ?? 'default';

    $args = [
        'post_type' => 'product',
        'posts_per_page' => 12,
        'orderby' => 'date',
        'order' => 'DESC',
        'tax_query' => [],
    ];

    if ($parent_category) {
        $args['tax_query'][] = [
            'taxonomy' => 'product_cat',
            'field' => 'id',
            'terms' => $parent_category,
        ];
    }

    if ($child_category) {
        $args['tax_query'][] = [
            'taxonomy' => 'product_cat',
            'field' => 'id',
            'terms' => $child_category,
        ];
    }

    if ($sort_by == 'price-asc' || $sort_by == 'price-desc') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = '_price';
        $args['order'] = ($sort_by == 'price-asc') ? 'ASC' : 'DESC';
    }

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            wc_get_template_part( 'content', 'product' );
        }
    }
    $products_html = ob_get_clean();

    wp_send_json_success( [ 'products' => $products_html ] );
}
add_action( 'wp_ajax_sp_get_products', 'sp_get_products' );
add_action( 'wp_ajax_nopriv_sp_get_products', 'sp_get_products' );

?>
