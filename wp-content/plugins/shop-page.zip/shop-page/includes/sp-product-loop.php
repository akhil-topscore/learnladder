<?php
// File: includes/ajax-handlers.php

function sp_get_child_categories() {
    $parent_category = $_GET['parent_category'] ?? 0;

    if (!$parent_category) {
        wp_send_json_error( [ 'message' => 'Invalid Parent Category' ] );
    }

    $child_categories = get_terms( [
        'taxonomy' => 'product_cat',
        'parent' => $parent_category,
        'hide_empty' => false
    ] );

    ob_start();
    echo '<option value="0">Select Child Category</option>';
    foreach ( $child_categories as $child_category ) {
        echo '<option value="' . esc_attr( $child_category->term_id ) . '">' . esc_html( $child_category->name ) . '</option>';
    }
    $output = ob_get_clean();

    wp_send_json_success( $output );
}
add_action( 'wp_ajax_sp_get_child_categories', 'sp_get_child_categories' );
add_action( 'wp_ajax_nopriv_sp_get_child_categories', 'sp_get_child_categories' );


function sp_get_products() {
    $parent_category = isset($_GET['parent_category']) ? $_GET['parent_category'] : 0;
    $child_category = isset($_GET['child_category']) ? $_GET['child_category'] : 0;
    $sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'default';

    $args = [
        'post_type' => 'product',
        'posts_per_page' => 12,
        'orderby' => 'date',
        'order' => 'DESC',
        'tax_query' => [],
    ];

    // Filter by parent category
    if ($parent_category) {
        $args['tax_query'][] = [
            'taxonomy' => 'product_cat',
            'field' => 'id',
            'terms' => $parent_category,
            'operator' => 'IN',
        ];
    }

    // Filter by child category
    if ($child_category) {
        $args['tax_query'][] = [
            'taxonomy' => 'product_cat',
            'field' => 'id',
            'terms' => $child_category,
            'operator' => 'IN',
        ];
    }

    // Sorting by price
    if ($sort_by == 'price-asc' || $sort_by == 'price-desc') {
        $args['orderby'] = 'meta_value_num';
        $args['meta_key'] = '_price';
        $args['order'] = ($sort_by == 'price-asc') ? 'ASC' : 'DESC';
    }

    $query = new WP_Query($args);

    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            wc_get_template_part('content', 'product'); // Display product content
        }
    } else {
        echo '<p>No products found.</p>';
    }
    $products_html = ob_get_clean();

    wp_send_json_success([ 'products' => $products_html ]);
}
add_action('wp_ajax_sp_get_products', 'sp_get_products');
add_action('wp_ajax_nopriv_sp_get_products', 'sp_get_products');

add_action( 'wp_ajax_sp_get_products', 'sp_get_products' );
add_action( 'wp_ajax_nopriv_sp_get_products', 'sp_get_products' );
?>
