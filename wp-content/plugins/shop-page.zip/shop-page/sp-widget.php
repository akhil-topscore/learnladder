<?php
/**
 * Plugin Name: Shop Page Widget
 * Description: A custom Elementor widget to display product cards with filter options, sorting, and pagination.
 * Version: 1.0
 * Author: Akhil Johns
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Include the merged functions file
require_once( __DIR__ . '/includes/shop-page-plugin.php' );

function load_elementor_widget() {
    require('/includes/shop-page-plugin.php');
    
    \Elementor\Plugin::instance()->widgets_manager->register( new \Elementor\My_Widget_1() );
}
add_action('init', 'load_elementor_widget')

function sp_load_shop_page_widget() {
    if ( did_action( 'elementor/loaded' ) ) {
        require_once( __DIR__ . '/includes/shop-page-plugin.php' );
    } else {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>Please install and activate <strong>Elementor</strong> to use the Shop Page Widget plugin.</p></div>';
        });
    }
}
add_action( 'plugins_loaded', 'sp_load_shop_page_widget' );


// Enqueue styles and scripts
function sp_enqueue_shop_page_assets() {
    wp_enqueue_style( 'sp-style', plugin_dir_url( __FILE__ ) . 'assets/css/sp-style.css' );
    wp_enqueue_script( 'sp-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/sp-scripts.js', array( 'jquery' ), false, true );
}
add_action( 'wp_enqueue_scripts', 'sp_enqueue_shop_page_assets' );

// Localize AJAX script
function sp_localize_ajax_script() {
    wp_localize_script( 'sp-scripts', 'sp_ajax_obj', [
        'ajax_url' => admin_url( 'admin-ajax.php' ),
    ]);
}
add_action( 'wp_enqueue_scripts', 'sp_localize_ajax_script' );

?>
