jQuery(document).ready(function($) {
    // Fetch child categories based on parent category selection
    $('#sp-parent-category').on('change', function() {
        var parentCategory = $(this).val();
        $.ajax({
            url: sp_ajax_obj.ajax_url,
            method: 'GET',
            data: {
                action: 'sp_get_child_categories',
                parent_category: parentCategory
            },
            success: function(response) {
                if (response.success) {
                    $('#sp-child-category').html(response.data);
                }
            }
        });
    });

    // Fetch products based on selected category and sort option
    function fetchProducts() {
        var parentCategory = $('#sp-parent-category').val();
        var childCategory = $('#sp-child-category').val();
        var sortBy = $('#sp-sort-by-price').data('sort'); // Sort option (e.g., price-asc)

        $.ajax({
            url: sp_ajax_obj.ajax_url,
            method: 'GET',
            data: {
                action: 'sp_get_products',
                parent_category: parentCategory,
                child_category: childCategory,
                sort_by: sortBy
            },
            success: function(response) {
                if (response.success) {
                    $('#sp-products-list').html(response.data.products);
                }
            }
        });
    }

    // Trigger products fetching on page load
    fetchProducts();

    // Add sorting functionality
    $('#sp-sort-by-price').on('click', function() {
        var currentSort = $(this).data('sort');
        var newSort = currentSort === 'price-asc' ? 'price-desc' : 'price-asc';
        $(this).data('sort', newSort);
        fetchProducts();
    });
});
