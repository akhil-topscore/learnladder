jQuery(document).ready(function($) {
    const scrollContainer = $('.hcs-container');
    const scrollAmount = 100; // Amount to scroll on each button click

    $('.hcs-scroll-right').on('click', function() {
        scrollContainer.animate({ scrollLeft: '+= ' + scrollAmount }, 300);
    });

    $('.hcs-scroll-left').on('click', function() {
        scrollContainer.animate({ scrollLeft: '-= ' + scrollAmount }, 300);
    });
});
