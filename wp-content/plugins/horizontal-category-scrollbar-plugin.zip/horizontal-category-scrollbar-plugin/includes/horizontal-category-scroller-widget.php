<?php

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class Horizontal_Category_Scroller_Widget extends Widget_Base {

    public function get_name() {
        return 'horizontal_category_scroller';
    }

    public function get_title() {
        return __( 'Horizontal Category Scroller', 'text-domain' );
    }

    public function get_icon() {
        return 'eicon-slider'; // You can use any Elementor icon here
    }

    public function get_categories() {
        return [ 'basic' ]; // You can assign this to your preferred category
    }

    protected function _register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => __( 'Content', 'text-domain' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'style_section',
            [
                'label' => __( 'Style', 'text-domain' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        // Add controls for customizing button appearance
        $this->add_control(
            'button_color',
            [
                'label' => __( 'Button Color', 'text-domain' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hcs-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => __( 'Button Text Color', 'text-domain' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .hcs-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        // Get categories
        $categories = get_terms(array(
            'taxonomy' => 'product_cat',
            'hide_empty' => true,
        ));

        echo '<div class="hcs-container">';
        foreach ( $categories as $category ) {
            echo '<button class="hcs-button">' . esc_html($category->name) . '</button>';
        }
        echo '<div class="hcs-scroll-left"><span>&lt;</span></div>';
        echo '<div class="hcs-scroll-right"><span>&gt;</span></div>';
        echo '</div>';
    }
}
